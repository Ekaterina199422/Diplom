package ru.netology.diplom.dto

data class PushToken(
    val token: String,
)

package ru.netology.diplom.model

data class LoggedModel(
    val name: String = "N/A",
    val login: String = "N/A",
    val password: String = "N/A",
)
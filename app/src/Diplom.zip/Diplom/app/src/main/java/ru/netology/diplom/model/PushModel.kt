package ru.netology.diplom.model

data class PushModel(
    val recipientId: Int,
    val content: String
)